//
//  Students.swift
//  HA2Monat6
//
//  Created by Maksat Edil on 8/1/24.
//

import Foundation
struct Student: Codable {
    let studentName: String
    let studentSurname: String
    let studentImage: String
}



